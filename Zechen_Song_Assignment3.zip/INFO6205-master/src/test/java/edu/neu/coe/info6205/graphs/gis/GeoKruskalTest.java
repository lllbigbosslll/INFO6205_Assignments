package edu.neu.coe.info6205.graphs.gis;

import org.junit.Test;

public class GeoKruskalTest {

    @Test
    public void getMST() {
    }

    @Test
    public void iterator() {
    }

    @Test
    public void getGeoMST() {
    }
}