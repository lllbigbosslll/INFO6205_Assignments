package edu.neu.coe.info6205.union_find;

public class UF_Client {

    public static int count(int n){
        int count = 0;
        UF h = new UF_HWQUPC(n);
        while(h.components() != 1) {
            int p = (int) Math.floor(Math.random() * n);
            int q = (int) Math.floor(Math.random() * n);
            if (!h.isConnected(p, q)) {
                h.connect(p, q);
                count++;
            }
        }
        return count;
    }

    // if the there is argument from the command line, take the argument and print the object# and the pair#
    // if there is no argument form the command line, run the experiment for a fixed set of 100 values
    public static void main(String[] args) {

        if (args.length > 0) {
            int arg = Integer.parseInt(args[0]);
            System.out.println("Objects#: n = " + arg + "    pairs#: m = " + count(arg));
        }
        else {
            for (int i = 100; i > 0; i--) {
                System.out.println("Objects#: n = " + i + "    pairs#: m = " + count(i));
            }
        }




    }
}

