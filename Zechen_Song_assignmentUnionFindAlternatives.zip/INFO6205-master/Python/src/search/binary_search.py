class BinarySearch(object):

    @staticmethod
    def binary_search(a, low, high, key):
        lo = low
        hi = high
        while hi >= lo:
            # TO BE IMPLEMENTED :: implement binary search
            
                
            # ... end of TO BE IMPLEMENTED
        return -1
